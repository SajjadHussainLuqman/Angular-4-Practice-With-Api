﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL_Project;
using DAL_Project;

namespace Web_Project
{
    public partial class menuUC : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<Category> main = new CategoryRepository().GetAll().OrderBy(id => id.SortOrder).ToList();
                List<Brand> Sub = new BrandRepository().GetAll().ToList();
                Menu menu = new Menu();
                int i = 0;
                foreach (Category item in main)
                {
                    MenuItem categoryItem = new MenuItem(item.Name, item.CategoryId.ToString());
                    MenuOne.Items.Add(categoryItem);

                    var qq = from n in Sub where n.CategoryId == item.CategoryId select n;
                    foreach (Brand itemSub in qq)
                    {
                        MenuItem childItem = new MenuItem(itemSub.Name, itemSub.BrandId.ToString());
                        MenuOne.Items[i].ChildItems.Add(childItem);
                    }
                    i++;
                }
                for (int j = 0; j < MenuOne.Items.Count; j++)
                {
                    if (MenuOne.Items[j].ChildItems.Count > 0)
                        MenuOne.Items[j].Selectable = false;
                }
                MenuOne.Height = 26;
                MenuOne.Width = 189;
            }
        }
        protected void MenuOne_MenuItemClick(object sender, MenuEventArgs e)
       {
            Response.Redirect("~/ProductsShow.aspx?MenuId=" + e.Item.ValuePath.Replace('/', ',')) ;
        }
    }
}