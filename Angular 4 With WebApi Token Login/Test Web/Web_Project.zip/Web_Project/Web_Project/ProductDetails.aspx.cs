﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL_Project;
using DAL_Project;

namespace Web_Project
{
    public partial class ProductDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int ProductId = Convert.ToInt32(Request.QueryString["ProductId"]);
                Product_Get be = new ProductRepository().ProductGetById(ProductId);
                thumb3.HRef = "images/"+be.PictureName;
                lblImg.Src = "images/" + be.PictureName;

                txtLength.InnerText = be.LengthAndHeight;
                txtName.InnerText = be.Name;
                txtTechnicalDetail.InnerHtml = be.Description;
                txtTentManufacturing.InnerText = be.TentManufacturing;
                txtTentMaterial.InnerText = be.TentMaterial;
                txtUsages.InnerText = be.Usages;

            }
        }
    }
}