﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL_Project;
using DAL_Project;

namespace Web_Project.Admin
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string logOut = Request.QueryString["LogOut"];
                if (!string.IsNullOrEmpty(logOut) && logOut == "1")
                {
                    Session["IsLogin"] = false;
                }
                else
                {
                    if (Session["IsLogin"] != null)
                    {
                        bool IsLogin = (bool)Session["IsLogin"];
                        if (IsLogin)
                        {
                            Response.Redirect("Admin.aspx");
                        }
                    }
                    else
                    {
                        Session["IsLogin"] = false;
                    }
                }
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            User be = new User();

            be.UserName = UserName.Value;
            be.Password = Password.Value;

            be= new UsersRepository().GetAll().Where(x=>x.UserName==be.UserName && x.Password==be.Password).FirstOrDefault();
            if (be!=null & be.UserName!=null)
            {
                Session["IsLogin"] = true;
                Session["UserId"] = be.UserId;
                Response.Redirect("Admin.aspx");
            }
            else
                lblResult.InnerText = "UserName or Password is invalid.";

        }
    }
}