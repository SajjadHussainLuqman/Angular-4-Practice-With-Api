﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL_Project;
using DAL_Project;

namespace Web_Project.Admin
{
    public partial class BrandForm : System.Web.UI.Page
    {
        public static int a = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                databound();
            }
        }

        public void databound()
        {
            List<Brand_Get> list = new BrandRepository().BrandGet();
            lvCategory.DataSource = list;
            lvCategory.DataBind();
        }

        
        protected void onItemEditingCallIt(object sender, ListViewEditEventArgs e)
        {
            lvCategory.EditIndex = e.NewEditIndex;
            databound();

            ListViewDataItem editItem = lvCategory.Items[lvCategory.EditIndex] as ListViewDataItem;
            DropDownList participantList = editItem.FindControl("ddlMainCategory") as DropDownList;
            List<Category> list = new CategoryRepository().GetAll().ToList();
            participantList.DataSource = list;
            participantList.DataTextField = "Name";
            participantList.DataValueField = "CategoryId";
            participantList.DataBind();
            string value = (editItem.FindControl("HiddenField1") as HiddenField).Value;
            participantList.SelectedValue = value;

            a = 5;
        }

        protected void onItemDeleteCallIt(object sender, ListViewDeleteEventArgs e)
        {
            string CategoryId = lvCategory.DataKeys[e.ItemIndex].Value.ToString();
            int id = Convert.ToInt32(CategoryId);
            Brand b = new BrandRepository().GetSingle(id);
            
            new BrandRepository().DeleteBrand(id);
            databound();
        }

        protected void onItemUpdateCallIt(object sender, ListViewUpdateEventArgs e)
        {
            Brand bee = new Brand();
            string SubCategoryId = lvCategory.DataKeys[e.ItemIndex].Value.ToString();
            TextBox txtSubCategoryName = lvCategory.Items[e.ItemIndex].FindControl("txtSubCategoryName") as TextBox;
            DropDownList MainCateId = lvCategory.Items[e.ItemIndex].FindControl("ddlMainCategory") as DropDownList;
            TextBox DisplayOrder = lvCategory.Items[e.ItemIndex].FindControl("txtOrder") as TextBox;

            bee.BrandId = Convert.ToInt32(SubCategoryId);
            bee.CategoryId = Convert.ToInt32(MainCateId.SelectedValue);
            bee.Name = txtSubCategoryName.Text;
            bee.SortOrder = Convert.ToInt32(DisplayOrder.Text);

            new BrandRepository().EditSave(bee);
            lvCategory.EditIndex = -1;
            databound();
            a = 0;
        }

        protected void onItemCanceling(object sender, ListViewCancelEventArgs e)
        {
            lvCategory.EditIndex = -1;
            databound();
        }

        protected void onItemInsertCallIt(object sender, ListViewInsertEventArgs e)
        {
            Brand bes = new Brand();
            TextBox subCategoryName = (e.Item.FindControl("txtSubCategoryName")) as TextBox;
            DropDownList ddlCategoryName = (e.Item.FindControl("ddlCategoryName")) as DropDownList;
            TextBox displayOrder = (e.Item.FindControl("txtDisplayOrderName")) as TextBox;

            bes.Name = subCategoryName.Text;
            bes.CategoryId = Convert.ToInt32(ddlCategoryName.SelectedValue);
            if (displayOrder.Text.Length > 0)
            {
                bes.SortOrder = Convert.ToInt32(displayOrder.Text);
            }
            new BrandRepository().AddSave(bes);
            databound();
        }

        protected void OnPReRend(object sender, EventArgs e)
        {
            List<Category> list = new CategoryRepository().GetAll().ToList();
            if (a == 0)
            {
                if (list.Count > 5)
                {
                    dpPager.Visible = true;
                    databound();
                }
                else
                {
                    dpPager.Visible = false;
                    databound();
                }
            }
            else
            {
                a = 0;
            }
        }

        protected void lvPopUp_ItemCreated(object sender, ListViewItemEventArgs e)
        {

            if (e.Item.ItemType == ListViewItemType.InsertItem)
            {
                DropDownList ddl = (DropDownList)e.Item.FindControl("ddlCategoryName");
                if (ddl != null)
                {
                    List<Category> list = new CategoryRepository().GetAll().ToList();
                    ddl.DataSource = list;
                    ddl.DataTextField = "Name";
                    ddl.DataValueField = "CategoryId";
                    ddl.DataBind();
                }
            }
        }
    }
}