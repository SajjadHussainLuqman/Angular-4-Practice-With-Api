﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL_Project;
using DAL_Project;

namespace Web_Project.Admin
{
    public partial class AllProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                databound();
                ddl();
            }
        }

        public void databound()
        {
            Product be = new Product();
            if(ddlCategory.SelectedIndex>0)
            be.CategoryId = Convert.ToInt32(ddlCategory.SelectedValue);
            if(ddlSub.SelectedIndex>0)
            be.BrandId = Convert.ToInt32(ddlSub.SelectedValue);
            be.Name = string.IsNullOrEmpty(txtName.Value)?null:txtName.Value;
            var list = new ProductRepository().ProductGet(be).ToList();
            ListView1.DataSource = list;
            ListView1.DataBind();
        }

        public void ddl()
        {
            List<Category> list = new CategoryRepository().GetAll().ToList();
            ddlCategory.DataSource = list;
            ddlCategory.DataTextField = "Name";
            ddlCategory.DataValueField = "CategoryId";
            ddlCategory.DataBind();
            ddlCategory.Items.Insert(0, "-Select-");

            List<Brand> listBrand = new BrandRepository().GetAll().ToList();
            ddlSub.DataSource = listBrand;
            ddlSub.DataTextField = "Name";
            ddlSub.DataValueField = "BrandId";
            ddlSub.DataBind();
            ddlSub.Items.Insert(0, "-Select-");

        }

        protected void ListView1_ItemDeleting(object sender, ListViewDeleteEventArgs e)
        {
            string CategoryId = ListView1.DataKeys[e.ItemIndex].Value.ToString();
            int id = Convert.ToInt32(CategoryId);
           
            new ProductRepository().DeleteProduct(id);
           
            databound();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

        }
    }
}