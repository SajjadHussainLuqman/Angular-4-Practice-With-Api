﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL_Project;
using DAL_Project;

namespace Web_Project.Admin
{
    public partial class CategoryForm : System.Web.UI.Page
    {
        public static int a = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                databound();
            }
        }

        public void databound()
        {
            List<Category> list = new CategoryRepository().GetAll().ToList();
            lvCategory.DataSource = list;
            lvCategory.DataBind();
        }
        protected void onItemEditingCallIt(object sender, ListViewEditEventArgs e)
        {
            lvCategory.EditIndex = e.NewEditIndex;
            databound();
            a = 5;
        }

        protected void onItemDeleteCallIt(object sender, ListViewDeleteEventArgs e)
        {
            string CategoryId = lvCategory.DataKeys[e.ItemIndex].Value.ToString();
            int id = Convert.ToInt32(CategoryId);
            Category b = new CategoryRepository().GetSingle(id);
            new CategoryRepository().DeleteCategory(id);
            databound();
        }

        protected void onItemUpdateCallIt(object sender, ListViewUpdateEventArgs e)
        {
            Category bee = new Category();
            string SubCategoryId = lvCategory.DataKeys[e.ItemIndex].Value.ToString();
            TextBox txtSubCategoryName = lvCategory.Items[e.ItemIndex].FindControl("txtSubCategoryName") as TextBox;
            TextBox DisplayOrder = lvCategory.Items[e.ItemIndex].FindControl("txtOrder") as TextBox;

            bee.CategoryId = Convert.ToInt32(SubCategoryId);
            bee.Name = txtSubCategoryName.Text;
            bee.SortOrder = Convert.ToInt32(DisplayOrder.Text);

            new CategoryRepository().EditSave(bee);
            lvCategory.EditIndex = -1;
            databound();
            a = 0;
        }

        protected void onItemCanceling(object sender, ListViewCancelEventArgs e)
        {
            lvCategory.EditIndex = -1;
            databound();
        }

        protected void onItemInsertCallIt(object sender, ListViewInsertEventArgs e)
        {
            Category bes = new Category();
            TextBox subCategoryName = (e.Item.FindControl("txtSubCategoryName")) as TextBox;
            TextBox displayOrder = (e.Item.FindControl("txtDisplayOrderName")) as TextBox;

            bes.Name = subCategoryName.Text;
            if (displayOrder.Text.Length > 0)
            {
                bes.SortOrder = Convert.ToInt32(displayOrder.Text);
            }
            new CategoryRepository().AddSave(bes);
            databound();
        }

        protected void OnPReRend(object sender, EventArgs e)
        {
            List<Category> list = new CategoryRepository().GetAll().ToList();
            if (a == 0)
            {
                if (list.Count > 5)
                {
                    dpPager.Visible = true;
                    databound();
                }
                else
                {
                    dpPager.Visible = false;
                    databound();
                }
            }
            else
            {
                a = 0;
            }
        }
    }
}