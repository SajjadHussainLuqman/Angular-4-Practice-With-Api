﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL_Project;
using DAL_Project;

namespace Web_Project.Admin
{
    public partial class ProductForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ddl();
                string ProductId = Request.QueryString["ProductId"];
                if (ProductId != null && ProductId.Length > 0)
                {
                    Product be = new ProductRepository().GetSingle(Convert.ToInt32(ProductId));
                    txtLengthAndHeight.Value = be.LengthAndHeight;
                    txtName.Value = be.Name;
                    txtTechnicalDetail.Text = be.Description;
                    txtTentManufacturing.Value = be.TentManufacturing;
                    txtTentMaterial.Value = be.TentMaterial;
                    txtUsages.Value = be.Usages;
                    chkIsDisplayAtHome.Checked = be.IsDisplayHome == null || be.IsDisplayHome==false ? false : true;
                    hdPix.Value = be.PictureName;
                    lblPix.Src = "../images/" + be.PictureName;

                    hdfProductId.Value = be.ProductId.ToString();

                    ddlCategory.SelectedValue = be.CategoryId.ToString();
                    ddlSub.SelectedValue = be.BrandId.ToString();

                }
                else
                {
                    hdfProductId.Value = "0";
                }
            }
        }

        public void ddl()
        {
            List<Category> list = new CategoryRepository().GetAll().ToList();
            ddlCategory.DataSource = list;
            ddlCategory.DataTextField = "Name";
            ddlCategory.DataValueField = "CategoryId";
            ddlCategory.DataBind();

            List<Brand> listBrand = new BrandRepository().GetAll().ToList();
            ddlSub.DataSource = listBrand;
            ddlSub.DataTextField = "Name";
            ddlSub.DataValueField = "BrandId";
            ddlSub.DataBind();
        }

        public string getUniqueName(string path, string fullName)
        {
            string justName, extention;
            string rename = "";
            int counter = 0;
            string NewName = "";

            string[] FileNameArray = fullName.Split('.');
            justName = FileNameArray[0];
            extention = FileNameArray[1];
            while (System.IO.File.Exists(path + justName + rename + "." + extention))
            {
                counter += 1;
                rename = counter.ToString();
            }
            NewName = justName + rename + "." + extention;
            return NewName;
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (ddlCategory.SelectedIndex < 1)
            {
                lblResult.Text = "Select Category";
                return;
            }

            if (ddlSub.SelectedIndex < 1)
            {
                lblResult.Text = "Select Sub";
                return;
            }

            Product be = new Product();
            be.Usages = txtUsages.Value;
            be.TentMaterial = txtTentMaterial.Value;
            be.TentManufacturing = txtTentManufacturing.Value;
            be.LengthAndHeight = txtLengthAndHeight.Value;
            be.SortOrder = 0;
            be.Name = txtName.Value;
            be.Description = txtTechnicalDetail.Text;
            be.ProductId = Convert.ToInt32(hdfProductId.Value);
            be.CategoryId = Convert.ToInt32(ddlCategory.SelectedValue);
            be.BrandId = Convert.ToInt32(ddlSub.SelectedValue);
            be.IsDisplayHome = chkIsDisplayAtHome.Checked;

            string path = Server.MapPath("../images/");
            if (fuPix.HasFile)
            {
                string NewName = getUniqueName(path, fuPix.FileName);
                fuPix.SaveAs(path + NewName);
                be.PictureName = NewName;
            }
            else
            {
                be.PictureName = hdPix.Value;
            }

            if (be.ProductId!=0)
            {
                new ProductRepository().EditSave(be);
                lblResult.Text = "Successfully Saved";
                
            }
            else
            {
                new ProductRepository().AddSave(be);
                clearAll();
                lblResult.Text = "Successfully Saved";
            }

        }

        public void clearAll()
        {
            txtLengthAndHeight.Value = "";
            txtName.Value = "";
            txtTechnicalDetail.Text = "";
            txtTentManufacturing.Value = "";
            txtTentMaterial.Value = "";
            txtUsages.Value = "";

            hdPix.Value   = "";
            lblPix.Src   = "";

            hdfProductId.Value = "";
        }
    }
}