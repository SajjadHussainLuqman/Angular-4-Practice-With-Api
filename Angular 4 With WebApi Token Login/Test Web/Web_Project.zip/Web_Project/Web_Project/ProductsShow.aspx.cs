﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL_Project;
using DAL_Project;

namespace Web_Project
{
    public partial class ProductsShow : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                string Menus = Request.QueryString["MenuId"];

                string[] listMenu = Menus.Split(',');
                int CategoryId = Convert.ToInt32(listMenu[0]);

                int SubId = 0;

                if(listMenu.Count()>1)
                {
                    SubId = Convert.ToInt32(listMenu[1]);
                }

                List<Product_Get> list = new ProductRepository().ProductGet(new Product() { CategoryId = CategoryId });
                if(list.Count>0 && SubId!=0)
                {
                    list = list.Where(x => x.BrandId == SubId).ToList();
                }

                lvShow.DataSource = list;
                lvShow.DataBind();

            }
        }
    }
}