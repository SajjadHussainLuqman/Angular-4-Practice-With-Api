﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using DAL_Project;

namespace BL_Project
{
    public class BrandRepository : GenericRepository<CommerceAppDBEntities, Brand>, IBrandRepository
    {
        public Brand GetSingle(int Id)
        {
            var query = GetAll().FirstOrDefault(x => x.BrandId == Id);
            return query;
        }

        public void EditSave(Brand b)
        {
            try
            {
                using (var obj = new CommerceAppDBEntities())
                {
                    Brand t = obj.Brands.FirstOrDefault(x => x.BrandId == b.BrandId);
                    t.CategoryId = b.CategoryId;
                    t.Name = b.Name;
                    t.SortOrder = b.SortOrder;
                    obj.SaveChanges();
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Brand_Get> BrandGet()
        {
            using (var obj=new CommerceAppDBEntities())
            {
              return  obj.usp_Brand_Get().ToList();
            }
        }

        public Brand_Get BrandGetById(int Id)
        {
            using (var obj = new CommerceAppDBEntities())
            {
              return   obj.usp_Brand_Get().FirstOrDefault(x=>x.BrandId==Id);
            }
        }


        public void DeleteBrand(int id)
        {
            try
            {
                using (var obj = new CommerceAppDBEntities())
                {
                    obj.Brands.Remove(obj.Brands.FirstOrDefault(e => e.BrandId == id));
                    obj.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
