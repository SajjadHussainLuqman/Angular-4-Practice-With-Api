﻿
using System;
using System.Linq;
using DAL_Project;
namespace BL_Project
{
    public class CategoryRepository : GenericRepository<CommerceAppDBEntities, Category>, ICategoryRepository
    {
        public Category GetSingle(int Id)
        {
            var query = GetAll().FirstOrDefault(x => x.CategoryId == Id);
            return query;
        }
        public void EditSave(Category b)
        {
            try
            {
                using (var obj = new CommerceAppDBEntities())
                {
                    Category c = obj.Categories.FirstOrDefault(x => x.CategoryId == b.CategoryId);
                    c.Name = b.Name;
                    c.SortOrder = b.SortOrder;
                    obj.SaveChanges();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void DeleteCategory(int id)
        {
            try
            {
                using (var obj = new CommerceAppDBEntities())
                {
                    obj.Categories.Remove(obj.Categories.FirstOrDefault(e => e.CategoryId == id));
                    obj.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
