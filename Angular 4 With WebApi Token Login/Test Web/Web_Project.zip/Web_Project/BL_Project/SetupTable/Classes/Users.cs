﻿
using System.Collections.Generic;
using System.Linq;
using DAL_Project;
namespace BL_Project
{
   public class UsersRepository : GenericRepository<CommerceAppDBEntities, User>, IUsers
    {
        public User GetSingle(int Id)
        {
            var query = GetAll().FirstOrDefault(x => x.UserId == Id);
            return query;
        }
    }
}
