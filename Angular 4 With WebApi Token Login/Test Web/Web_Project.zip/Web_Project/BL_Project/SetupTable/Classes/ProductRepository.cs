﻿
using System.Linq;
using System;
using System.Collections.Generic;
using DAL_Project;
namespace BL_Project
{
    public class ProductRepository : GenericRepository<CommerceAppDBEntities, Product>, IProductRepository
    {
        public Product GetSingle(int Id)
        {
            var query = GetAll().FirstOrDefault(x => x.ProductId == Id);
            return query;
        }
        public void EditSave(Product b)
        {
            try
            {
                using (var obj = new CommerceAppDBEntities())
                {
                    Product c = obj.Products.FirstOrDefault(x => x.ProductId == b.ProductId);
                    c.Name = b.Name;
                    c.SortOrder = b.SortOrder;
                    c.CategoryId = b.CategoryId;
                    c.BrandId = b.BrandId;
                    c.Description = b.Description;
                    c.IsDisplayHome = b.IsDisplayHome;
                    c.LengthAndHeight = b.LengthAndHeight;
                    c.PictureName = b.PictureName;
                    c.SortOrder = b.SortOrder;
                    c.TentManufacturing = b.TentManufacturing;
                    c.TentMaterial = b.TentMaterial;
                    c.Usages = b.Usages;
                    obj.SaveChanges();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void DeleteProduct(int id)
        {
            try
            {
                using (var obj = new CommerceAppDBEntities())
                {
                    obj.Products.Remove(obj.Products.FirstOrDefault(e => e.ProductId == id));
                    obj.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<Product_Get> ProductGet(Product be)
        {
            using (var obj = new CommerceAppDBEntities())
            {
                return obj.usp_Product_Get(be.BrandId,be.CategoryId,be.Name).ToList();
            }
        }

        public Product_Get ProductGetById(int Id)
        {
            using (var obj = new CommerceAppDBEntities())
            {
                return obj.usp_Product_Get(null,null,null).FirstOrDefault(x => x.ProductId == Id);
            }
        }
    }
}
