﻿
using DAL_Project;
namespace BL_Project
{
    public interface ICategoryRepository : IGenericRepository<Category>
    {
        Category GetSingle(int Id);
    }
}
