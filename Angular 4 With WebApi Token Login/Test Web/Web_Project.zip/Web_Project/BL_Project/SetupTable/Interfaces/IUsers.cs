﻿
using DAL_Project;
namespace BL_Project
{
   public interface IUsers : IGenericRepository<User>
    {
        User GetSingle(int Id);
    }
}
