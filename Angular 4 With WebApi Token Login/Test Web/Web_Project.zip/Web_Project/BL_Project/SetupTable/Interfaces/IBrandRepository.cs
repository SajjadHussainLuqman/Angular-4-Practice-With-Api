﻿
using DAL_Project;

namespace BL_Project
{
    public interface IBrandRepository : IGenericRepository<Brand>
    {
        Brand GetSingle(int Id);
    }
}
