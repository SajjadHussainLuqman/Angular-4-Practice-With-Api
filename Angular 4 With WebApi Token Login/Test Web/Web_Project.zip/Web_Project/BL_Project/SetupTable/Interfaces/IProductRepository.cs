﻿
using DAL_Project;
namespace BL_Project
{
    public interface IProductRepository : IGenericRepository<Product>
    {
        Product GetSingle(int Id);
    }
}
