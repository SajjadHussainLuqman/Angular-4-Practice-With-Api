export class Category {
    CategoryId: Number;
    Name: String;
    IsActive: Boolean;
}