import { Injectable } from '@angular/core';
import { LoginService } from './login.service';

@Injectable()
export class AuthenticationService {

    CanLogin: Boolean = false;

    constructor(private _loginService: LoginService) { }

    login(username: string, password: string) {

        let LoginSuccess: Boolean = false;

        this._loginService.Login(this.getLoginBody(username, password).toString()).subscribe(
            response => {

                localStorage.setItem('access_token', response.json().access_token);
                localStorage.setItem('expires_in', response.json().expires_in);
                localStorage.setItem('token_type', response.json().token_type);
                localStorage.setItem('userName', response.json().userName);

                LoginSuccess = true;
            },
            error => {
                LoginSuccess = false;
                console.log(error);
            }
        );

        return LoginSuccess;

    }

    logout() {
        localStorage.clear();
    }

    isAuthUser() {
        if (!localStorage.getItem('access_token') || !localStorage.getItem('expires')
            || +(new Date(localStorage.getItem('expires'))) <= +(new Date())) {
            return false;
        } else {
            return true;
        }
    }

    getLoginBody(userName: string, password: string): string {
        let loginBody: string = "username=" + userName + "&password=" + password + "&grant_type=password";
        return loginBody;
    }
}
