import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule , Routes } from '@angular/router';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';

import { CartonComponent } from './carton/index';
import { PalletComponent } from './pallet/index';
import {  TrailerComponent } from './trailer/index';

import { businessRoutes } from './business.routes';

@NgModule({
    declarations:[
        CartonComponent,PalletComponent, TrailerComponent
    ],
    providers: [

    ],
    imports: [
        CommonModule,FormsModule,ReactiveFormsModule, RouterModule.forRoot(businessRoutes)
    ],
    exports:[

    ]
})

export class BusinessModule { }

