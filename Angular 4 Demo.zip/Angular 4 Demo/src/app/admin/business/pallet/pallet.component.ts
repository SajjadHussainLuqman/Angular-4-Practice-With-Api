import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pallet',
  templateUrl: './pallet.component.html',
  styleUrls: ['./pallet.component.css']
})
export class PalletComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
