
import {  Routes } from '@angular/router';

import { CartonComponent } from './carton/index';
import { PalletComponent } from './pallet/index';
import {  TrailerComponent } from './trailer/index';

export const businessRoutes: Routes = [

{ path: 'Carton', component: CartonComponent },
{ path: 'Pallet', component: PalletComponent },
{ path: 'Trailer', component: TrailerComponent }
];