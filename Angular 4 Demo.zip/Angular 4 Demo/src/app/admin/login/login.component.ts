import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../services/authenticate.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  invalidLogin:boolean;
  returnUrl: string;

  constructor(private _router:Router
              ,private _activatedRoute:ActivatedRoute
              ,private _authenticationService:AuthenticationService) {
              }

              
  ngOnInit()
  {
      this._authenticationService.logout();
      this.returnUrl = this._activatedRoute.snapshot.queryParams['returnUrl'] || 'Admin';
  }


  signIn(anyValue:any)
  {
      
          this._router.navigate(['Admin']);
      
  }

}
