import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sale-chart',
  templateUrl: './sale-chart.component.html',
  styleUrls: ['./sale-chart.component.css']
})
export class SaleChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
