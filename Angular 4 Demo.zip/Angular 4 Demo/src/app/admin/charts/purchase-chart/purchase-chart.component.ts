import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-chart',
  templateUrl: './purchase-chart.component.html',
  styleUrls: ['./purchase-chart.component.css']
})
export class PurchaseChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
