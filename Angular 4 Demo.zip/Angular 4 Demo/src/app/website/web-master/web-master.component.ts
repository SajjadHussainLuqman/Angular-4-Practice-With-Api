import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-web-master',
  templateUrl: './web-master.component.html',
  styleUrls: ['./web-master.component.css']
})
export class WebMasterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
