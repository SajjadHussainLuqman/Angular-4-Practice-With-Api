import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-web-index',
  templateUrl: './web-index.component.html',
  styleUrls: ['./web-index.component.css']
})
export class WebIndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
